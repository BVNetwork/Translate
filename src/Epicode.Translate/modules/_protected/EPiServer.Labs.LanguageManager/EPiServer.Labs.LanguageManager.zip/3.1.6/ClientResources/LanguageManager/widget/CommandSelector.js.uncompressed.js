require({cache:{
'url:epi-languagemanager/widget/templates/CommandSelector.html':"﻿<div class=\"epi-menu--inverted\">\n    <div class=\"epi-dijitTooltipContainer\">\n        <div data-dojo-attach-point=\"headerNode\" class=\"epi-invertedTooltip\">\n            <div class=\"epi-tooltipDialogTop\">\n                <span data-dojo-attach-point=\"header\"></span>\n                <div class=\"dijitTooltipConnector\"></div>\n            </div>\n        </div>\n        <div class=\"epi-tooltipDialogContent--max-height\">\n            <table class=\"dijitReset dijitMenu epi-tooltipDialogMenu epi-menuInverted epi-mediumMenuItem\" style=\"width: 100%\" cellspacing=\"0\">\n                <tbody data-dojo-attach-point=\"containerNode\"></tbody>\n            </table>\n        </div>\n    </div>\n</div>"}});
﻿define("epi-languagemanager/widget/CommandSelector", [
// Dojo
    "dojo/_base/declare",
    "dojo/_base/array",
    "dojo/_base/lang",
    "dojo/when",
    "dojo/dom-style",

// Dojox
    "dojox/html/entities",

// Dijit
    "dijit/registry",
    "dijit/MenuItem",
    "dijit/_TemplatedMixin",

// EPi CMS
    "epi-cms/widget/SelectorMenuBase",

// Resouces
    "dojo/text!./templates/CommandSelector.html"

], function (
// Dojo
    declare,
    array,
    lang,
    when,
    domStyle,

// Dojox
    htmlEntities,

// Dijit
    registry,
    MenuItem,
    _TemplatedMixin,

// EPi CMS
    SelectorMenuBase,

// Resouces
    template
) {
    // module:
    //      "epi-languagemanager/widget/CommandSelector"
    // summary:
    //      Used for selecting command options

    return declare([SelectorMenuBase, _TemplatedMixin], {

        // templateString: [protected] String
        //      Html template for the slector
        templateString: template,

        itemClass: MenuItem,

        _setHeaderDisplayAttr: function(visible) {
            domStyle.set(this.headerNode, "display", !!visible ? "" : "none");
        },

        _setHeadingTextAttr: function (text) {
            this._set("headingText", text);
            this.header.innerHTML = text;
        },

        _setItemsAttr: function (items) {
            this._set("items", items);
            this._setup();
        },

        _setup: function () {

            if(!this.items) {
                return;
            }

            //Destroy the old menu items
            this._removeMenuItems();

            array.forEach(this.items, function(itemData) {

                var menuItem = new this.itemClass({
                    label: htmlEntities.encode(itemData.label),
                    value: itemData.value,
                    _setSelected: this._setSelected,
                    onClick: lang.hitch(this, function (evt) {
                        var target = evt.srcElement || evt.target;
                        if (registry.getEnclosingWidget(target) instanceof this.itemClass) {
                            this.onItemSelected(menuItem.value);
                        }
                    })
                });

                if (itemData.disabled === 'disabled') {
                    menuItem.set('disabled', 'disabled');
                }

                this.addChild(menuItem);
            }, this);
        },

        onItemSelected: function (item) {
            // summary:
            //   Raised when a item is selected, it will fire the view setting change.
            //
            // tags:
            //    event
        },

        _removeMenuItems: function () {
            var items = this.getChildren();
            items.forEach(function (item) {
                this.removeChild(item);
                item.destroy();
            }, this);
        },

        _setSelected: function (selected) {
            // fix js error when blur menu item. Need to improve later.
        }
    });
});